import os
root_dir = r'C:\Users\gm67149\Desktop\Questionare\Questionare\Root'
file_list = []
for sub_dir, dirs, files in os.walk(root_dir):
    for file in files:
        file_list.append(os.path.join(sub_dir, file))

emp_list = []
stud_list = []


for file_name in file_list:
    with open(file_name,'r') as handle:
        file_data = handle.read().split('\n')[1:-1]
        if 'emp' in file_name:
            for line in file_data:
                emp_list.append(line.split(','))
        if 'stud' in file_name:
            for line in file_data:
                stud_list.append(line.split(','))


count_dat_files = len(file_list)
total_emp_count = len(emp_list)




count_male_stud = 0
count_female_stud = 0
total_stud_count = len(stud_list)
stud_pass_count = 0
stud_fail_count = 0
for student in stud_list:
    if student[2]=='m':
        count_male_stud += 1
    else:
        count_female_stud += 1
    if int(student[4][:-1])<35:
        stud_fail_count += 1
    else:
        stud_pass_count += 1



print(f'Count of passed students: {stud_pass_count}')
print(f'Count of failed students: {stud_fail_count}')
print(f'Total count of employees: {total_emp_count}')
print(f'Total count of students: {total_stud_count}')
