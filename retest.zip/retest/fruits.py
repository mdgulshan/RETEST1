import os
root_dir = r'C:\Users\gm67149\Desktop\Questionare\Questionare\Root'
file_list = []
for sub_dir, dirs, files in os.walk(root_dir):
    for file in files:
        file_list.append(os.path.join(sub_dir, file))


fruit_list = []

for file_name in file_list:
    with open(file_name,'r') as handle:
        file_data = handle.read().split('\n')[1:-1]
        if 'Fruit' in file_name:
            for line in file_data:
                fruit_list.append(line.split(','))

total_quantity = 0
unique_fruits = set()
quantity_list = [0, 0, 0] #Apple, orange, grapes
apples_quantity = 0
oranges_quantity = 0
grapes_quantity = 0

for fruit in fruit_list:
    #print(fruit[1].lower())
    total_quantity += int(fruit[3])
    unique_fruits.add(fruit[1])
    if fruit[1].lower() == 'apple':
        quantity_list[0] += int(fruit[3])
    elif fruit[1].lower() == 'orange':
        quantity_list[1] += int(fruit[3])
    elif fruit[1].lower() == 'grapes':
        quantity_list[2] += int(fruit[3])


print(f'Quantity(in Kgs) of Apples, Oranges and Grapes: {quantity_list}')

print(f'Unique list of fruits: {unique_fruits}')

print(f'Total quantity of fruits(in Kgs): {total_quantity}')
