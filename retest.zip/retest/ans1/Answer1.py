# import csv
# from prettytable import PrettyTable
import pandas as pd
# with open("emp1.dat", "r") as CSVR:
#     emp_details = csv.reader(CSVR)
#     colName = next(emp_details)
#     print(colName)
#     emp_table = PrettyTable(next(emp_details))
#
#     for rec in emp_details:
#         # print(rec)
#         emp_table.add_row(rec)
#
# CSVR.close()
#
# print(emp_table)
# df=pd.DataFrame(emp_table)
# print(df)
#
# # FW = open("Emp.csv", "r")
# #
# # gender = {}
# # for line in FW.readlines():
# #     g = line.split(",")[2]
# #
# #     if g in gender:
# #         gender[g] += 1
# #     else:
# #         gender[g] = 1
# #
# # FW.close()
# #
# # print(f"gender :{gender}")

unique_dept=[]
Sum=0
df=pd.read_csv("emp1.dat")
c=df["gen"].tolist()
z=df["dept"].unique()
unique_dept=unique_dept+z.tolist()
y=df["salary"].tolist()
Sum=Sum+sum(y)

#print(unique_dept)
female_emp_count1=c.count("f")
male_emp_count1=c.count("m")

df=pd.read_csv("emp4.dat")
c=df["gen"].tolist()
z=df["dept"].unique()
unique_dept=unique_dept+z.tolist()

female_emp_count2=c.count("f")
male_emp_count2=c.count("m")
y=df["salary"].tolist()
Sum=Sum+sum(y)

df=pd.read_csv("emp5.dat")
c=df["gen"].tolist()
z=df["dept"].unique()
unique_dept=unique_dept+z.tolist()

female_emp_count3=c.count("f")
male_emp_count4=c.count("m")
y=df["salary"].tolist()
Sum=Sum+sum(y)

df=pd.read_csv("emp6.dat")
c=df["gen"].tolist()
z=df["dept"].unique()
unique_dept=unique_dept+z.tolist()

female_emp_count5=c.count("f")
male_emp_count5=c.count("m")
y=df["salary"].tolist()
Sum=Sum+sum(y)

df=pd.read_csv("emp8.dat")
c=df["gen"].tolist()
z=df["dept"].unique()
unique_dept=unique_dept+z.tolist()

female_emp_count6=c.count("f")
male_emp_count6=c.count("m")
y=df["salary"].tolist()
Sum=Sum+sum(y)





df=pd.read_csv("stud1.dat")
c=df["gen"].tolist()

female_stud1_count1=c.count("f")
male_stud1_count1=c.count("m")

df=pd.read_csv("stud7.dat")
c=df["gen"].tolist()

female_stud7_count2=c.count("f")
male_stud7_count2=c.count("m")

df=pd.read_csv("stud4.dat")
c=df["gen"].tolist()

female_stud4_count3=c.count("f")
male_stud4_count3=c.count("m")

df=pd.read_csv("stud2.dat")
c=df["gen"].tolist()

female_stud2_count4=c.count("f")
male_stud2_count4=c.count("m")

print("*"*40)

print("Total numbers males students and employee are =",male_stud7_count2+male_stud1_count1+male_emp_count5+male_emp_count6+male_emp_count4+male_emp_count2+male_emp_count1)
print("Total numbers females students and employe are",female_stud2_count4+female_stud4_count3+female_stud1_count1+female_stud7_count2+female_emp_count6+female_emp_count5+female_emp_count3+female_emp_count1+female_emp_count2)

print("*"*40)

# df=pd.read_csv("stud7.dat")
#
#
# print(f'Count of passed students: {stud_pass_count}')
# print(f'Count of failed students: {stud_fail_count}')

print("*"*40)

#print(set(unique_dept))

print("*"*40)

print("Sum of all salaries are =",Sum)

print("*"*40)

import os
path =r"C:\Users\gm67149\PycharmProjects\zensar\retest\ans1"

os.chdir(path)

def read_files(filepath):
    with open(filepath, 'r') as file:
        next(file)
        for line in file.readlines():
            g = line.split(",")[3]
            if g in dept:
                dept[g] = line.split(",")[2]
            else:
                dept[g] = 1
        file.close()
dept={}
for file in os.listdir():
    filepath =f"{path}/{file}"
    if file.endswith(".dat"):
        read_files(filepath)
print(f"unique depts is :{dept.keys()}")